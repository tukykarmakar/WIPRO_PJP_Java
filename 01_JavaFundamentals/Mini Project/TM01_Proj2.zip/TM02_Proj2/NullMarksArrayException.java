package com.mile1.exception;

public class NullMarksArrayException extends Exception
{
	public NullMarksArrayException()
	{
		this.toString();
	}
	public String toString()
	{
		return "NullMarksArrayException occured";
	}
}