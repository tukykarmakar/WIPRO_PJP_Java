package com.mile1.exception;

public class NullStudentException extends Exception
{
	public NullStudentException()
	{
		this.toString();
	}
	public String toString()
	{
		return "NullNameException occured";
	}
}